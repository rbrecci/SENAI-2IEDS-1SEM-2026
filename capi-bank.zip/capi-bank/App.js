// App.js — Capibank (mini versão funcional)
// Não depende de nenhuma lib externa além de "react" e "react-native",
// que já vêm em qualquer projeto Expo/React Native novo.
// É só substituir o conteúdo do seu App.js por este arquivo e rodar.

import React, { useState } from 'react';
import {
  SafeAreaView,
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  StatusBar,
} from 'react-native';

const theme = {
  moss: '#3F5B3B',
  mossDark: '#24361F',
  river: '#4E93A0',
  fur: '#A9713F',
  amber: '#D98E4A',
  cream: '#F4EFDD',
  bg: '#DDD9C3',
  textDark: '#22301E',
};

const actions = [
  { label: 'Pix', emoji: '💧', color: theme.river },
  { label: 'Transferir', emoji: '🔄', color: theme.fur },
  { label: 'Pagar', emoji: '🧾', color: theme.amber },
  { label: 'Recarga', emoji: '📱', color: theme.moss },
];

const offers = [
  { title: 'Capivalt 🐹', desc: 'Seu dinheiro rendendo até na água', color: theme.river },
  { title: 'Cartão da Toca', desc: 'Peça o seu sem anuidade', color: theme.fur },
];

const transactions = [
  { emoji: '🌾', name: 'Feira orgânica', date: 'Hoje', value: -42.9 },
  { emoji: '💧', name: 'Pix recebido · Miguel', date: 'Hoje', value: 120 },
  { emoji: '🛶', name: 'Passeio de canoa', date: 'Ontem', value: -65 },
  { emoji: '🐊', name: 'Seguro da toca', date: '2 dias atrás', value: -28.5 },
];

function formatMoney(value) {
  const abs = Math.abs(value).toFixed(2).replace('.', ',');
  return `${value > 0 ? '+' : '-'} R$ ${abs}`;
}

export default function App() {
  const [showBalance, setShowBalance] = useState(true);

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="light-content" backgroundColor={theme.mossDark} />
      <ScrollView style={styles.screen} contentContainerStyle={{ paddingBottom: 24 }}>

        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Boa tarde</Text>
            <Text style={styles.userName}>Rafael 🦫</Text>
          </View>
          <View style={styles.avatar}>
            <Text style={{ fontSize: 20 }}>🦫</Text>
          </View>
        </View>

        {/* Cartão de saldo */}
        <View style={styles.balanceCard}>
          <View style={styles.balanceRow}>
            <Text style={styles.balanceLabel}>SALDO CAPIBANK</Text>
            <TouchableOpacity onPress={() => setShowBalance(!showBalance)}>
              <Text style={{ fontSize: 16 }}>{showBalance ? '🙈' : '👁️'}</Text>
            </TouchableOpacity>
          </View>
          <Text style={styles.balanceValue}>
            {showBalance ? 'R$ 4.286,70' : 'R$ ••••••'}
          </Text>
        </View>

        {/* Ações rápidas */}
        <View style={styles.actionsRow}>
          {actions.map((a) => (
            <TouchableOpacity key={a.label} style={styles.actionItem} activeOpacity={0.7}>
              <View style={[styles.actionIcon, { backgroundColor: a.color }]}>
                <Text style={{ fontSize: 18 }}>{a.emoji}</Text>
              </View>
              <Text style={styles.actionLabel}>{a.label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Carrossel de ofertas */}
        <Text style={styles.sectionTitle}>Pra você 🌿</Text>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingLeft: 20, paddingRight: 8 }}
        >
          {offers.map((o) => (
            <View key={o.title} style={[styles.offerCard, { backgroundColor: o.color }]}>
              <Text style={styles.offerTitle}>{o.title}</Text>
              <Text style={styles.offerDesc}>{o.desc}</Text>
            </View>
          ))}
        </ScrollView>

        {/* Extrato */}
        <View style={styles.extractHeader}>
          <Text style={styles.sectionTitle}>Últimas atividades</Text>
        </View>
        <View style={styles.extractList}>
          {transactions.map((t, i) => (
            <View
              key={i}
              style={[
                styles.transactionRow,
                i === transactions.length - 1 && { borderBottomWidth: 0 },
              ]}
            >
              <View style={styles.transactionLeft}>
                <View style={styles.transactionIcon}>
                  <Text style={{ fontSize: 16 }}>{t.emoji}</Text>
                </View>
                <View>
                  <Text style={styles.transactionName}>{t.name}</Text>
                  <Text style={styles.transactionDate}>{t.date}</Text>
                </View>
              </View>
              <Text
                style={[
                  styles.transactionValue,
                  { color: t.value > 0 ? theme.moss : theme.textDark },
                ]}
              >
                {formatMoney(t.value)}
              </Text>
            </View>
          ))}
        </View>
      </ScrollView>

      {/* Navegação inferior (visual, decorativa) */}
      <View style={styles.bottomNav}>
        <View style={styles.navItem}>
          <Text style={{ fontSize: 18 }}>🏠</Text>
          <Text style={[styles.navLabel, { color: theme.moss }]}>Início</Text>
        </View>
        <View style={styles.navItem}>
          <Text style={{ fontSize: 18, opacity: 0.4 }}>💳</Text>
          <Text style={styles.navLabelInactive}>Cartão</Text>
        </View>
        <View style={styles.navItem}>
          <Text style={{ fontSize: 18, opacity: 0.4 }}>🔲</Text>
          <Text style={styles.navLabelInactive}>Pix</Text>
        </View>
        <View style={styles.navItem}>
          <Text style={{ fontSize: 18, opacity: 0.4 }}>👤</Text>
          <Text style={styles.navLabelInactive}>Perfil</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: theme.cream,
  },
  screen: {
    flex: 1,
  },
  header: {
    backgroundColor: theme.mossDark,
    paddingHorizontal: 24,
    paddingTop: 16,
    paddingBottom: 48,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  greeting: {
    color: '#C7D6BE',
    fontSize: 13,
  },
  userName: {
    color: theme.cream,
    fontSize: 20,
    fontWeight: '700',
    marginTop: 2,
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  balanceCard: {
    backgroundColor: theme.cream,
    marginHorizontal: 20,
    marginTop: -36,
    borderRadius: 20,
    padding: 20,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 6 },
    elevation: 6,
  },
  balanceRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 6,
  },
  balanceLabel: {
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.5,
    color: theme.textDark,
    opacity: 0.6,
  },
  balanceValue: {
    fontSize: 28,
    fontWeight: '800',
    color: theme.mossDark,
  },
  actionsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    marginTop: 20,
  },
  actionItem: {
    alignItems: 'center',
    gap: 6,
  },
  actionIcon: {
    width: 48,
    height: 48,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  actionLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: theme.textDark,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: theme.textDark,
    marginTop: 24,
    marginBottom: 10,
    marginLeft: 20,
  },
  offerCard: {
    width: 200,
    borderRadius: 16,
    padding: 16,
    marginRight: 12,
  },
  offerTitle: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 14,
  },
  offerDesc: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 12,
    marginTop: 4,
  },
  extractHeader: {
    marginTop: 4,
  },
  extractList: {
    marginHorizontal: 20,
  },
  transactionRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0,0,0,0.06)',
  },
  transactionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  transactionIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  transactionName: {
    fontSize: 13,
    fontWeight: '600',
    color: theme.textDark,
  },
  transactionDate: {
    fontSize: 11,
    color: theme.textDark,
    opacity: 0.5,
    marginTop: 1,
  },
  transactionValue: {
    fontSize: 13,
    fontWeight: '700',
  },
  bottomNav: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    paddingVertical: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(0,0,0,0.06)',
    backgroundColor: '#fff',
  },
  navItem: {
    alignItems: 'center',
    gap: 3,
  },
  navLabel: {
    fontSize: 10,
    fontWeight: '700',
  },
  navLabelInactive: {
    fontSize: 10,
    color: theme.textDark,
    opacity: 0.4,
  },
});